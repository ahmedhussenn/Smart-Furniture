import 'package:flutter/material.dart';

const Color black = Colors.black;
const Color white = Colors.white;
const Color orange = Color.fromRGBO(250, 134, 86, 1);

const double appPadding = 30.0;